﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROG6221
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        { //Populating User Inputs
            rtbDetails.AppendText(" " + "Number Of Ingredients:" + NumIngredi.Value.ToString()+"\n");
            rtbDetails.AppendText(" " +"Name of Ingredient:"   + txtName.Text + "\n");
            rtbDetails.AppendText(" " + "Unit of Measurement:"   + txtMeas.Text + "\n");
            rtbDetails.AppendText(" " + "Number of Steps:"   + numSteps.Value.ToString() + "\n");
             // Scaling factors
            if (rad2.Checked)
            {
                int Product;
                Product = Convert.ToInt32(numQuant.Value) * 2;
                rtbDetails.AppendText(" " + "Quantity of Ingredient:" + Product.ToString() + "\n");
            }

            else if (rad3.Checked)
            {
                int Product;
                Product = Convert.ToInt32(numQuant.Value) * 2;
                rtbDetails.AppendText(" " + "Quantity of Ingredient:" + Product.ToString() + "\n");
            }

            else if (radhalf.Checked)
            {
                double Product;
                Product = Convert.ToInt32(numQuant.Value) * 0.5;
                rtbDetails.AppendText(" " + "Quantity of Ingredient:" + Product.ToString() + "\n");
            }

            else
            {
                rtbDetails.AppendText(" " + "Quantity of Ingredient:" + numQuant.Value.ToString() + "\n");
            }

            rtbDetails.AppendText(" " + "Steps Description:" + rtbDescription.Text + "\n");



        } 
        

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        { 
            // Clearing all the details
            rtbDetails.Text = "";
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {  
            //Reseting the variables
            numQuant.ResetText();
            numSteps.ResetText();
            txtMeas.Text = "";
            txtName.Text = "";
            NumIngredi.ResetText();
            radhalf.Checked = false;
            rad2.Checked = false;
            rad3.Checked = false;
            rtbDescription.Text = "";
        }

        private void rtbDescription_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
