﻿namespace PROG6221
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NumIngredi = new System.Windows.Forms.NumericUpDown();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtMeas = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.rtbDetails = new System.Windows.Forms.RichTextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.BtnReset = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.rad2 = new System.Windows.Forms.RadioButton();
            this.rad3 = new System.Windows.Forms.RadioButton();
            this.radhalf = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.rtbDescription = new System.Windows.Forms.RichTextBox();
            this.numQuant = new System.Windows.Forms.NumericUpDown();
            this.numSteps = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.NumIngredi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numQuant)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSteps)).BeginInit();
            this.SuspendLayout();
            // 
            // NumIngredi
            // 
            this.NumIngredi.Location = new System.Drawing.Point(366, 34);
            this.NumIngredi.Name = "NumIngredi";
            this.NumIngredi.Size = new System.Drawing.Size(120, 20);
            this.NumIngredi.TabIndex = 0;
            this.NumIngredi.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(386, 96);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 20);
            this.txtName.TabIndex = 1;
            this.txtName.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtMeas
            // 
            this.txtMeas.Location = new System.Drawing.Point(386, 198);
            this.txtMeas.Name = "txtMeas";
            this.txtMeas.Size = new System.Drawing.Size(100, 20);
            this.txtMeas.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Please Enter the Number of Ingredients:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(86, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Quantity of the Ingredient:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(86, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Unit Of Measurement:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(86, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(203, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Please Enter the Name of The Ingredient:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(86, 250);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Number Of Steps:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(154, 453);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // rtbDetails
            // 
            this.rtbDetails.Location = new System.Drawing.Point(579, 34);
            this.rtbDetails.Name = "rtbDetails";
            this.rtbDetails.Size = new System.Drawing.Size(209, 349);
            this.rtbDetails.TabIndex = 12;
            this.rtbDetails.Text = "";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(352, 453);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(102, 23);
            this.btnClear.TabIndex = 13;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // BtnReset
            // 
            this.BtnReset.Location = new System.Drawing.Point(579, 453);
            this.BtnReset.Name = "BtnReset";
            this.BtnReset.Size = new System.Drawing.Size(75, 23);
            this.BtnReset.TabIndex = 14;
            this.BtnReset.Text = "Reset";
            this.BtnReset.UseVisualStyleBackColor = true;
            this.BtnReset.Click += new System.EventHandler(this.BtnReset_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(86, 413);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Scale Factor:";
            // 
            // rad2
            // 
            this.rad2.AutoSize = true;
            this.rad2.Location = new System.Drawing.Point(412, 411);
            this.rad2.Name = "rad2";
            this.rad2.Size = new System.Drawing.Size(74, 17);
            this.rad2.TabIndex = 17;
            this.rad2.TabStop = true;
            this.rad2.Text = "2 (Double)";
            this.rad2.UseVisualStyleBackColor = true;
            // 
            // rad3
            // 
            this.rad3.AutoSize = true;
            this.rad3.Location = new System.Drawing.Point(566, 409);
            this.rad3.Name = "rad3";
            this.rad3.Size = new System.Drawing.Size(66, 17);
            this.rad3.TabIndex = 18;
            this.rad3.TabStop = true;
            this.rad3.Text = "3 (Triple)";
            this.rad3.UseVisualStyleBackColor = true;
            // 
            // radhalf
            // 
            this.radhalf.AutoSize = true;
            this.radhalf.Location = new System.Drawing.Point(261, 411);
            this.radhalf.Name = "radhalf";
            this.radhalf.Size = new System.Drawing.Size(68, 17);
            this.radhalf.TabIndex = 19;
            this.radhalf.TabStop = true;
            this.radhalf.Text = "0.5 (Half)";
            this.radhalf.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(86, 329);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "Steps Description:";
            // 
            // rtbDescription
            // 
            this.rtbDescription.Location = new System.Drawing.Point(386, 287);
            this.rtbDescription.Name = "rtbDescription";
            this.rtbDescription.Size = new System.Drawing.Size(170, 96);
            this.rtbDescription.TabIndex = 22;
            this.rtbDescription.Text = "";
            this.rtbDescription.TextChanged += new System.EventHandler(this.rtbDescription_TextChanged);
            // 
            // numQuant
            // 
            this.numQuant.Location = new System.Drawing.Point(386, 149);
            this.numQuant.Name = "numQuant";
            this.numQuant.Size = new System.Drawing.Size(120, 20);
            this.numQuant.TabIndex = 23;
            // 
            // numSteps
            // 
            this.numSteps.Location = new System.Drawing.Point(386, 243);
            this.numSteps.Name = "numSteps";
            this.numSteps.Size = new System.Drawing.Size(120, 20);
            this.numSteps.TabIndex = 24;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 515);
            this.Controls.Add(this.numSteps);
            this.Controls.Add(this.numQuant);
            this.Controls.Add(this.rtbDescription);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.radhalf);
            this.Controls.Add(this.rad3);
            this.Controls.Add(this.rad2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.BtnReset);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.rtbDetails);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMeas);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.NumIngredi);
            this.Name = "Form1";
            this.Text = "User Recipe";
            ((System.ComponentModel.ISupportInitialize)(this.NumIngredi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numQuant)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSteps)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown NumIngredi;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtMeas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RichTextBox rtbDetails;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button BtnReset;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton rad2;
        private System.Windows.Forms.RadioButton rad3;
        private System.Windows.Forms.RadioButton radhalf;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RichTextBox rtbDescription;
        private System.Windows.Forms.NumericUpDown numQuant;
        private System.Windows.Forms.NumericUpDown numSteps;
    }
}

